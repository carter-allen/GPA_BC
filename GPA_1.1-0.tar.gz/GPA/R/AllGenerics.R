
# generic methods for "GPA" class

setGeneric( "fdr",
    function( object, ... )
    standardGeneric("fdr")
)

setGeneric( "assoc",
    function( object, ... )
    standardGeneric("assoc")
)

setGeneric( "cov",
    function( object, ... )
    standardGeneric("cov")
)

setGeneric( "se",
    function( object, ... )
    standardGeneric("se")
)

setGeneric( "estimates",
    function( object, ... )
    standardGeneric("estimates")
)
